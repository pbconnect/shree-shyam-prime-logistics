const express=require("express");
const fs=require("fs"); const path=require("path"); const app=express();
const PORT=process.env.PORT||3000; const DB=path.join(__dirname,"bookings.json");
app.use(express.json()); app.use(express.static(path.join(__dirname,"../public")));
function read(){try{return JSON.parse(fs.readFileSync(DB,"utf8"))}catch{return[]}}
function save(x){fs.writeFileSync(DB,JSON.stringify(x,null,2))}
app.get("/api/bookings",(req,res)=>res.json(read()));
app.post("/api/bookings",(req,res)=>{let a=read();let x={id:"SSPL"+Date.now().toString().slice(-7),...req.body,status:"pending",createdAt:new Date().toISOString()};a.push(x);save(a);res.json(x)});
app.patch("/api/bookings/:id",(req,res)=>{let a=read(),i=a.findIndex(x=>x.id===req.params.id);if(i<0)return res.status(404).json({error:"not found"});a[i]={...a[i],...req.body};save(a);res.json(a[i])});
app.listen(PORT,()=>console.log(`Shree Shyam Prime Logistics running on http://localhost:${PORT}`));